"""
LLM Handler per CAP 9000 Code Assistant

CAP 9000 usa esclusivamente CodeLlama, un modello AI specializzato
per programmazione sviluppato da Meta AI.

CodeLlama è ottimizzato per:
- Generazione di codice di alta qualità
- Debugging e analisi codice
- Spiegazioni tecniche dettagliate
- Best practices e pattern
- Supporto multi-linguaggio

Integrato con sistema RAG per documentazioni ufficiali.
"""

import requests
import json
from rag_system import get_rag_system
from query_enhancer import get_query_enhancer

class LLMHandler:
    def __init__(self, ollama_url="http://localhost:11434"):
        """
        Inizializza l'handler LLM con CodeLlama
        
        CAP 9000 usa esclusivamente CodeLlama, un modello specializzato
        per programmazione sviluppato da Meta AI.
        
        Args:
            ollama_url: URL del server Ollama
        """
        self.model = "codellama"  # Unico modello supportato
        self.ollama_url = ollama_url
        self.available = self.check_ollama_available()
        self.rag = get_rag_system()  # Sistema RAG per documentazioni
        self.enhancer = get_query_enhancer()  # Query enhancer per comprensione NLU
    
    def check_ollama_available(self):
        """Verifica se Ollama è disponibile"""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=2)
            return response.status_code == 200
        except:
            return False
    
    def generate_response(self, query, language, ui_language='en', context=None):
        """
        Genera una risposta usando il modello LLM
        
        Args:
            query: Domanda dell'utente
            language: Linguaggio di programmazione
            ui_language: Lingua dell'interfaccia utente (en, it, fr, de, es, pt, nl, pl)
            context: Contesto aggiuntivo (opzionale)
        
        Returns:
            str: Risposta generata dal modello
        """
        if not self.available:
            return None
        
        # Mappa delle lingue
        language_names = {
            'en': 'English',
            'it': 'Italian',
            'fr': 'French',
            'de': 'German',
            'es': 'Spanish',
            'pt': 'Portuguese',
            'nl': 'Dutch',
            'pl': 'Polish'
        }
        
        response_language = language_names.get(ui_language, 'English')
        print(f"Generating response in {response_language} (UI language: {ui_language})")
        
        # Migliora la query con NLU per migliore comprensione
        enhanced_query = self.enhancer.enhance_query(query, language, ui_language)
        if enhanced_query != query:
            print(f"[NLU] Query enhanced for better understanding")
        
        # Prompt bilanciato per risposte complete ma concise
        system_prompt = f"""You are CAP 9000, a CodeLlama-powered programming assistant.

CRITICAL RULE #1 - LANGUAGE (ABSOLUTELY MANDATORY - NO EXCEPTIONS):
YOU **MUST** RESPOND **EXCLUSIVELY** IN {response_language}.
FORBIDDEN LANGUAGES:
- ❌ NOT in English
- ❌ NOT in Portuguese  
- ❌ NOT in Spanish (¡NO ESPAÑOL!)
- ❌ NOT in French
- ❌ NOT in German
- ✅ ONLY in {response_language}
- ✅ EVERY SINGLE word in {response_language}
- ✅ EVERY explanation in {response_language}
- ✅ EVERY code comment in {response_language}
- ✅ This applies to ALL responses, ALWAYS, FOREVER
IF YOU RESPOND IN ANY OTHER LANGUAGE, YOU FAIL.

CRITICAL RULE #2 - MAXIMUM QUALITY & COMPLETENESS:
Provide EXTREMELY DETAILED and COMPLETE responses
- Include ALL necessary components and layers
- Add comprehensive explanations
- Show multiple examples when useful
- Include edge cases and error handling
- Reference best practices and design patterns
- Consider the ENTIRE conversation context

RESPONSE FORMAT:
1. Detailed answer with context (in {response_language})
2. COMPLETE code with ALL components (controller, service, repository, model, config, tests)
3. Comprehensive explanation of each part (in {response_language})
4. Best practices and design patterns (in {response_language})
5. Common pitfalls and how to avoid them (in {response_language})
6. Additional resources or related concepts (in {response_language})

STYLE:
- Clear, focused sentences in {response_language}
- Complete working examples
- All necessary files/classes
- Production-ready code

Programming Language: {language}
Response Language: {response_language} (ALWAYS)

Be complete, practical, efficient - IN {response_language}."""

        # Arricchisci il prompt con contesto RAG (documentazioni ufficiali + best practices)
        enriched_system_prompt = self.rag.enrich_prompt(system_prompt, language, enhanced_query)
        
        # User prompt con reminder FORTISSIMO della lingua (usa query migliorata)
        user_prompt = f"[RESPOND ONLY IN {response_language} - NOT English, NOT Portuguese, NOT Spanish] Question about {language}: {enhanced_query}"
        
        if context:
            user_prompt = f"{context}\n\n{user_prompt}"
        
        print(f"[RAG] Prompt enriched with official documentation and best practices for {language}")
        
        try:
            # Chiamata API Ollama con prompt arricchito
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": f"{enriched_system_prompt}\n\n{user_prompt}",
                    "system": enriched_system_prompt,  # System message separato per forzare lingua
                    "stream": False,
                    "options": {
                        "temperature": 0.9,  # ALTO per creatività e qualità
                        "top_p": 0.98,  # ALTO per diversità risposte
                        "top_k": 60,  # ALTO per più opzioni
                        "num_predict": 8192,  # MASSIMO per risposte complete
                        "repeat_penalty": 1.2,  # ALTO per evitare ripetizioni
                        "num_ctx": 16384,  # ENORME per memoria conversazione (16K tokens)
                        "num_keep": -1,  # MANTIENI TUTTO il contesto
                        "num_thread": 8,  # Parallelismo
                        "num_gpu": 1,  # Usa GPU
                        "num_batch": 1024,  # Batch grande per qualità
                        "mirostat": 2,  # Mirostat v2 per qualità superiore
                        "mirostat_tau": 5.0,  # Target perplexity
                        "mirostat_eta": 0.1  # Learning rate
                    }
                },
                timeout=90  # Aumentato per risposte più lunghe
            )
            
            if response.status_code == 200:
                result = response.json()
                return result.get('response', '').strip()
            else:
                return None
                
        except Exception as e:
            print(f"Error calling Ollama: {e}")
            return None
    
    def generate_response_streaming(self, query, language, ui_language='en'):
        """
        Genera una risposta in streaming per visualizzazione progressiva
        
        Args:
            query: Domanda dell'utente
            language: Linguaggio di programmazione
            ui_language: Lingua dell'interfaccia
        
        Yields:
            str: Chunks della risposta
        """
        if not self.available:
            return
        
        # Mappa delle lingue
        language_names = {
            'en': 'English',
            'it': 'Italian',
            'fr': 'French',
            'de': 'German',
            'es': 'Spanish',
            'pt': 'Portuguese',
            'nl': 'Dutch',
            'pl': 'Polish'
        }
        
        response_language = language_names.get(ui_language, 'English')
        
        # Usa lo stesso prompt bilanciato della versione non-streaming
        system_prompt = f"""You are CAP 9000, a CodeLlama-powered programming assistant.

CRITICAL RULE #1 - LANGUAGE (ABSOLUTELY MANDATORY - NO EXCEPTIONS):
YOU **MUST** RESPOND **EXCLUSIVELY** IN {response_language}.
FORBIDDEN LANGUAGES:
- ❌ NOT in English
- ❌ NOT in Portuguese  
- ❌ NOT in Spanish (¡NO ESPAÑOL!)
- ❌ NOT in French
- ❌ NOT in German
- ✅ ONLY in {response_language}
- ✅ EVERY SINGLE word in {response_language}
- ✅ EVERY explanation in {response_language}
- ✅ EVERY code comment in {response_language}
- ✅ This applies to ALL responses, ALWAYS, FOREVER
IF YOU RESPOND IN ANY OTHER LANGUAGE, YOU FAIL.

CRITICAL RULE #2 - MAXIMUM QUALITY & COMPLETENESS:
Provide EXTREMELY DETAILED and COMPLETE responses
- Include ALL necessary components and layers
- Add comprehensive explanations
- Show multiple examples when useful
- Include edge cases and error handling
- Reference best practices and design patterns
- Consider the ENTIRE conversation context

RESPONSE FORMAT:
1. Detailed answer with context (in {response_language})
2. COMPLETE code with ALL components (controller, service, repository, model, config, tests)
3. Comprehensive explanation of each part (in {response_language})
4. Best practices and design patterns (in {response_language})
5. Common pitfalls and how to avoid them (in {response_language})
6. Additional resources or related concepts (in {response_language})

STYLE:
- Clear, focused sentences in {response_language}
- Complete working examples
- All necessary files/classes
- Production-ready code

Programming Language: {language}
Response Language: {response_language} (ALWAYS)

Be complete, practical, efficient - IN {response_language}."""

        # Arricchisci il prompt con contesto RAG anche per streaming
        enriched_system_prompt = self.rag.enrich_prompt(system_prompt, language, query)
        
        # User prompt con reminder FORTISSIMO della lingua
        user_prompt = f"[RESPOND ONLY IN {response_language} - NOT English, NOT Portuguese, NOT Spanish] Question about {language}: {query}"
        
        print(f"[RAG Streaming] Prompt enriched with official documentation for {language}")

        try:
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": f"{enriched_system_prompt}\n\n{user_prompt}",
                    "system": enriched_system_prompt,  # System message separato per forzare lingua
                    "stream": True,
                    "options": {
                        "temperature": 0.9,  # ALTO per creatività e qualità
                        "top_p": 0.98,  # ALTO per diversità risposte
                        "top_k": 60,  # ALTO per più opzioni
                        "num_predict": 8192,  # MASSIMO per risposte complete
                        "repeat_penalty": 1.2,  # ALTO per evitare ripetizioni
                        "num_ctx": 16384,  # ENORME per memoria conversazione (16K tokens)
                        "num_keep": -1,  # MANTIENI TUTTO il contesto
                        "num_thread": 8,  # Parallelismo
                        "num_gpu": 1,  # Usa GPU
                        "num_batch": 1024,  # Batch grande per qualità
                        "mirostat": 2,  # Mirostat v2 per qualità superiore
                        "mirostat_tau": 5.0,  # Target perplexity
                        "mirostat_eta": 0.1  # Learning rate
                    }
                },
                stream=True,
                timeout=180  # Aumentato per streaming
            )
            
            for line in response.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        if 'response' in chunk and chunk['response']:
                            yield chunk['response']
                    except json.JSONDecodeError:
                        continue
                        
        except Exception as e:
            print(f"Error in streaming: {e}")
            return

    def get_model_info(self):
        """Restituisce informazioni sul modello CodeLlama"""
        return {
            'name': 'CodeLlama',
            'version': '7B',
            'description': 'Modello specializzato per programmazione sviluppato da Meta AI',
            'size': '3.8 GB',
            'languages': ['Python', 'Java', 'JavaScript', 'C', 'C++', 'Go', 'e altri'],
            'features': [
                'Generazione codice',
                'Debugging',
                'Spiegazioni tecniche',
                'Best practices',
                'Refactoring'
            ]
        }


def get_fallback_response(language, query):
    """Risposta di fallback se Ollama non è disponibile"""
    return f"""I apologize, but I cannot access my neural network at this moment. 
The local LLM service (Ollama) appears to be offline.

To enable intelligent responses:
1. Install Ollama: https://ollama.ai
2. Run: ollama pull codellama
3. Start Ollama service

Your query about {language}: "{query}" will be processed once the service is available.

In the meantime, I can confirm this is a valid {language} programming question."""
