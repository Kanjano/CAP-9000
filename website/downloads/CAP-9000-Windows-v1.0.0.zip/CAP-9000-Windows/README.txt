CAP 9000 - Cognitive Assistance Program
========================================

INSTALLAZIONE:
1. Installa Python 3.9+: https://www.python.org/downloads/
2. Installa Ollama: https://ollama.ai/download
3. Apri terminale in questa cartella
4. Esegui: pip install -r requirements.txt
5. Esegui: ollama pull codellama
6. Doppio click su CAP9000.bat

SUPPORTO:
antonio.web2music@gmail.com
